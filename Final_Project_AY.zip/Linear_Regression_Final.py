import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error

# Load the dataset from CSV file
data = pd.read_csv("DATASET_PATH")

#This will tell the program what columns should be used as features when training.
features = ['Open', 'High', 'Low']
X = data[features]
y = data['Close']

# Split data into training and testing sets.
# Test size is 0.116 as that is the final 28 days of the dataset 
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1116, random_state=1)
                                                    
# Create and train the linear regression model
model = LinearRegression()
model.fit(X_train, y_train)

# Evaluate the model - this is number will give the user an idea of how accurate the predictions are
y_pred = model.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
print("Mean Squared Error:", mse)
print("Predictions:", y_pred)
print("Actual", X_test)

# Plot actual vs predicted values
plt.figure(figsize=(10, 6))
sorted_indices = X_test.index.argsort()
plt.xticks(range(1, 29))
plt.plot(range(len(y_test)), y_test.iloc[sorted_indices], color='blue', label='Actual')
plt.plot(range(len(y_test)), y_pred[sorted_indices], color='red', label='Predicted')
plt.xlabel('Prediction Period')
plt.ylabel('Stock Price')   
plt.title('Actual vs Predicted Values')
plt.legend()
plt.show()